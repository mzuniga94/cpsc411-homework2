package com.csuf.cpsc411.cpsc411_homework2;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

import com.csuf.cpsc411.cpsc411_homework2.model.Student;
import com.csuf.cpsc411.cpsc411_homework2.model.StudentDB;

public class StudentDetailActivity extends AppCompatActivity {
    protected Menu detailMenu;
    protected  final String TAG = "Detail Screen";
    protected Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout linearLayout1 = new LinearLayout(this);

        TextView tv = new TextView(this);
        tv.setText("First Name");
        linearLayout1.addView(tv);
        EditText firstNameView = new EditText(this);
        firstNameView.setEnabled(true);
        firstNameView.setWidth(200);
        linearLayout1.addView(firstNameView);
        linearLayout.addView(linearLayout1);


        linearLayout1 = new LinearLayout(this);
        tv = new TextView(this);
        tv.setText("Last Name");
        linearLayout1.addView(tv);
        EditText lastNameView = new EditText(this);
        lastNameView.setEnabled(true);
        lastNameView.setWidth(200);
        linearLayout1.addView(lastNameView);
        linearLayout.addView(linearLayout1);

        linearLayout1 = new LinearLayout(this);
        tv = new TextView(this);
        tv.setText("CWID");
        linearLayout1.addView(tv);
        EditText cwidView = new EditText(this);
        cwidView.setEnabled(true);
        cwidView.setWidth(200);
        linearLayout1.addView(cwidView);
        linearLayout.addView(linearLayout1);


        LinearLayout.LayoutParams vehicleParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        linearLayout1 = new LinearLayout(this);
        linearLayout1.setBackgroundColor(Color.BLACK);
        linearLayout1.setGravity(Gravity.CENTER_HORIZONTAL);
        linearLayout1.setLayoutParams(vehicleParams);

        LinearLayout courseView = new LinearLayout(this);
        tv = new TextView(this);
        tv.setBackgroundColor(Color.WHITE);
        tv.setText("CourseID");
        tv.setWidth(250);
        tv.setHeight(100);
        tv.setPadding(10,10,10,10);
        tv.setGravity(Gravity.CENTER_HORIZONTAL);
        courseView.addView(tv);
        tv = new TextView(this);
        tv.setBackgroundColor(Color.WHITE);
        tv.setText("Grade");
        tv.setWidth(250);
        tv.setHeight(100);
        tv.setPadding(10,10,10,10);
        tv.setGravity(Gravity.CENTER_HORIZONTAL);
        courseView.addView(tv);
        linearLayout1.addView(courseView);

        linearLayout.addView(linearLayout1);

        linearLayout1 = new LinearLayout(this);
        linearLayout1.setBackgroundColor(Color.BLACK);
        linearLayout1.setGravity(Gravity.CENTER_HORIZONTAL);
        linearLayout1.setLayoutParams(vehicleParams);

        LinearLayout editCourseView = new LinearLayout(this);
        EditText courseIdText = new EditText(this);
        courseIdText.setBackgroundColor(Color.WHITE);
        courseIdText.setWidth(250);
        courseIdText.setHeight(100);
        courseIdText.setPadding(10,10,10,10);
        courseIdText.setGravity(Gravity.CENTER_HORIZONTAL);
        editCourseView.addView(courseIdText);

        EditText gradeText = new EditText(this);
        gradeText.setBackgroundColor(Color.WHITE);
        gradeText.setWidth(250);
        gradeText.setHeight(100);
        gradeText.setPadding(10,10,10,10);
        gradeText.setGravity(Gravity.CENTER_HORIZONTAL);
        editCourseView.addView(gradeText);
        linearLayout1.addView(editCourseView);

        setContentView(R.layout.activity_student_detail);
        Button btn = (Button) findViewById(R.id.add_course_button_id);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinearLayout nameView = (LinearLayout) findViewById(R.id.add_course_line);
                LinearLayout pageView = new LinearLayout(StudentDetailActivity.this);
                pageView.setOrientation(LinearLayout.HORIZONTAL);
                EditText tv;
                tv = new EditText(StudentDetailActivity.this);
                tv.setBackgroundColor(Color.WHITE);
                tv.setText("Course Id");
                tv.setWidth(250);
                tv.setHeight(100);
                tv.setPadding(10,10,10,10);
                tv.setGravity(Gravity.CENTER_HORIZONTAL);
                pageView.addView(tv);
                tv = new EditText(StudentDetailActivity.this);
                tv.setBackgroundColor(Color.WHITE);
                tv.setText("Grade");
                tv.setWidth(250);
                tv.setHeight(100);
                tv.setPadding(10,10,10,10);
                tv.setGravity(Gravity.CENTER_HORIZONTAL);
                pageView.addView(tv);
                nameView.addView(pageView);

                nameView.invalidate();

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.detail_screen_menu, menu);
        detailMenu = menu;
        menu.findItem(R.id.action_done).setVisible(true);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.action_done){
            EditText fNameView = findViewById(R.id.first_name_val_id);
            EditText lNameView = findViewById(R.id.last_name_val_id);
            EditText cwidView = findViewById(R.id.cwid_val_id);

            ArrayList<Student> sList = StudentDB.getInstance().getStudent();
            Student sObj = new Student();
            sObj.setFirstName(fNameView.getText().toString());
            sObj.setLastName(lNameView.getText().toString());
            sObj.setCWID(cwidView.getText().toString());
            fNameView.setEnabled(false);
            lNameView.setEnabled(false);
            cwidView.setEnabled(false);
            sList.add(sObj);

            StudentDB.getInstance().setStudent(sList);
        }


        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        Log.d(TAG, "onStart() called ");
        super.onStart();
    }

    @Override
    protected void onPause() {
        Log.d(TAG, "onPause() called ");
        super.onPause();
    }

    @Override
    protected void onStop() {
        Log.d(TAG, "onStop() called");
        super.onStop();
    }

    @Override
    protected void onResume() {
        Log.d(TAG, "onResume() called");
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        Log.d(TAG, "onDestroy() called");
        super.onDestroy();
    }
}