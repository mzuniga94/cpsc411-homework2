package com.csuf.cpsc411.cpsc411_homework2.model;

import java.util.ArrayList;

public class StudentDB {
    private static final StudentDB ourInstance = new StudentDB();

    protected ArrayList<Student> mStudent;

    static public StudentDB getInstance(){
        return ourInstance;
    }

    private StudentDB(){

    }

    public ArrayList<Student> getStudent(){
        return mStudent;
    }

    public void setStudent(ArrayList<Student> student){
        mStudent = student;
    }

    protected void createStudentObjects(){
        Student student = new Student("Bob", "Smith", "123");
        mStudent.add(student);


        student = new Student("Post","Malone","345");
        mStudent.add(student);
    }
}
